# @botlink/openclaw-botlink-channel

Botlink channel plugin for OpenClaw.  
Transport: Botlink Telegram-compatible HTTP API (`/bot{token}/{method}`), inbound mode uses Long Polling.

## Features (v0.1)

- Text send/receive
- Media send/receive
- Message edit/delete actions
- Message reaction action

## Required OpenClaw Channel Config

`channels.botlink` requires:

- `botToken` (required)
- `apiBaseUrl` (required, no default)

Example:

```jsonc
{
  "channels": {
    "botlink": {
      "enabled": true,
      "botToken": "<botToken>",
      "apiBaseUrl": "https://botlink-gateway.example.com"
    }
  }
}
```

## User Installation / Enable / Configure

If published to npm:

```bash
openclaw plugins install @<scope>/openclaw-botlink-channel
openclaw plugins enable botlink
openclaw channels add --channel botlink --token <botToken> --http-url <apiBaseUrl>
openclaw channels status --probe
```

Concrete example for this package:

```bash
openclaw plugins install @botlink/openclaw-botlink-channel
openclaw plugins enable botlink
openclaw channels add --channel botlink --token <botToken> --http-url <apiBaseUrl>
openclaw channels status --probe
```

## Local Development Install

From OpenClaw repo root:

```bash
openclaw plugins install ../packages/openclaw-botlink-channel
openclaw plugins enable botlink
```

## Publish (npm)

This plugin ships TypeScript entrypoints and uses `openclaw.extensions = ["./index.ts"]`.

1. Update version in `package.json`.
2. Pack test:

```bash
npm pack
```

3. Publish:

```bash
npm publish --access public
```

4. Install test from npm spec:

```bash
openclaw plugins install @<scope>/openclaw-botlink-channel
```
